# Serveur Socket.IO - Course des Modals (FR)

Ce petit serveur Node.js / Socket.IO est prêt à être déployé sur Render.
Il gère :
- la création de salles (code 4 chiffres),
- la jonction des joueurs,
- le lancement de la partie,
- l'envoi de questions, la réception des réponses,
- la mécanique de boost (flamme) et le podium de fin.

## Déploiement rapide sur Render
1. Crée un dépôt GitHub public et uploade tous les fichiers du projet.
2. Sur Render : New + → Web Service → Public Git Repository → colle l'URL de ton dépôt.
3. Build command : `npm install`
4. Start command : `node server.js`
5. Déploie. L'URL fournie par Render (ex: https://modals-race-server.onrender.com) sera l'URL à coller dans ton frontend React.

## Notes
- Ce serveur stocke tout en mémoire. Si le serveur redémarre, les salles sont réinitialisées.
- Les textes d'événements envoyés par le serveur sont en français.
