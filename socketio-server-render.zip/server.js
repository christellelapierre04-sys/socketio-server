import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';

// Petit serveur Socket.IO pour "Course des Modals" — messages en français
// Fonctionnalités:
// - création/join de salle (code 4 chiffres)
// - gestion simple des joueurs (max 6)
// - distribution des questions, collecte des réponses
// - boost (flamme) : suppression d'un choix possible (serveur envoie l'index à retirer)
// - en mémoire seulement (redémarrage réinitialise tout)

const app = express();
app.use(cors());
app.get('/', (req, res) => res.send('Serveur Socket.IO pour Course des Modals (FR)'));

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET','POST']
  }
});

const FINISH_DISTANCE = 20;
const QUESTION_TIME = 30; // secondes
const BOOST_DURATION = 30; // secondes

// Petite banque de questions (anglais) — 3 niveaux, travel sectors
const QUESTIONS = {
  easy: [
    { q: "The train is late; they ___ be delayed by the storm.", choices: ["must","might","should"], a: 1, sector: "Transport" },
    { q: "Guests ___ check out by 11 AM according to hotel policy.", choices: ["must","might","could"], a: 0, sector: "Accommodation" },
    { q: "You ___ try the chef's special — it's excellent.", choices: ["should","might","can"], a: 0, sector: "Food" }
  ],
  medium: [
    { q: "The tour guide didn't show up; he ___ have missed his flight.", choices: ["must","might","should"], a: 0, sector: "Transport" },
    { q: "They ___ have eaten already — the plates are empty.", choices: ["must","could","might"], a: 0, sector: "Food" }
  ],
  hard: [
    { q: "By the time we arrived, the restaurant ___ have closed — there were no lights.", choices: ["must","might","could"], a: 0, sector: "Food" },
    { q: "If she had left earlier, she ___ have caught the ferry.", choices: ["would","could","might"], a: 0, sector: "Transport" }
  ]
};

// Rooms in memory
const rooms = {}; // roomCode -> { hostId, level, players: [{id, name, position, consecutive, boostAvailable, boostTimer, ready}], currentIndex: {playerId: idx}, finished }

function genRoomCode() {
  let code;
  do {
    code = Math.floor(1000 + Math.random() * 9000).toString();
  } while (rooms[code]);
  return code;
}

io.on('connection', (socket) => {
  console.log('[socket] connecté', socket.id);

  socket.on('createRoom', (data, cb) => {
    const code = genRoomCode();
    rooms[code] = {
      hostId: socket.id,
      level: data?.level || 'easy',
      players: [],
      currentIndex: {},
      finished: false
    };
    console.log(`[room] créée ${code} par ${socket.id}`);
    if (cb) cb({ room: code });
  });

  socket.on('joinRoom', (payload, cb) => {
    // payload: { room, name }
    const room = rooms[payload.room];
    if (!room) {
      if (cb) cb({ success: false, message: 'Salle introuvable.'});
      return;
    }
    if (room.players.length >= 6) {
      if (cb) cb({ success: false, message: 'Salle pleine.'});
      return;
    }
    const player = { id: socket.id, name: payload.name || 'Joueur', position: 0, consecutive: 0, boostAvailable: false, boostTimer: 0, ready: false };
    room.players.push(player);
    socket.join(payload.room);
    console.log(`[room] ${payload.name} rejoint ${payload.room}`);
    // inform caller of success and local id
    if (cb) cb({ success: true, playerId: socket.id });
    // broadcast lobby update
    io.to(payload.room).emit('lobbyUpdate', { players: room.players.map(p => ({ id: p.id, name: p.name, position: p.position, boostAvailable: p.boostAvailable, boostTimer: p.boostTimer })) });
  });

  socket.on('startGame', (payload) => {
    // payload: { room, level }
    const room = rooms[payload.room];
    if (!room) return;
    room.level = payload.level || room.level;
    room.finished = false;
    // reset players
    room.players.forEach(p => {
      p.position = 0;
      p.consecutive = 0;
      p.boostAvailable = false;
      p.boostTimer = 0;
    });
    // initialize currentIndex for each player
    room.players.forEach((p, idx) => {
      room.currentIndex[p.id] = 0;
    });
    io.to(payload.room).emit('gameStart', { players: room.players.map(p => ({ id: p.id, name: p.name, position: p.position, boostAvailable: p.boostAvailable, boostTimer: p.boostTimer })) });
    // send first question to each player
    room.players.forEach((p) => {
      const q = pickQuestion(room.level, room.currentIndex[p.id]);
      io.to(p.id).emit('playerQuestion', { playerId: p.id, question: q });
    });
  });

  socket.on('answer', (payload) => {
    // payload: { room, playerId, choice }
    const room = rooms[payload.room];
    if (!room) return;
    const player = room.players.find(pl => pl.id === payload.playerId);
    if (!player) return;
    const qIndex = room.currentIndex[player.id] || 0;
    const question = pickQuestion(room.level, qIndex);
    const correct = payload.choice !== null && payload.choice === question.a;
    if (correct) {
      player.position += 2;
      player.consecutive = (player.consecutive || 0) + 1;
      if (player.consecutive >= 3 && !player.boostAvailable) {
        player.boostAvailable = true;
        player.boostTimer = BOOST_DURATION;
        // start boost countdown per-player
        const interval = setInterval(() => {
          player.boostTimer -= 1;
          if (player.boostTimer <= 0) {
            player.boostAvailable = false;
            clearInterval(interval);
          }
          io.to(payload.room).emit('gameState', { players: room.players.map(p => ({ id: p.id, name: p.name, position: p.position, boostAvailable: p.boostAvailable, boostTimer: p.boostTimer })) });
        }, 1000);
      }
    } else {
      player.position = Math.max(0, player.position - 1);
      player.consecutive = 0;
    }

    // advance to next question for this player
    room.currentIndex[player.id] = (room.currentIndex[player.id] || 0) + 1;

    // emit updated game state to room
    io.to(payload.room).emit('gameState', { players: room.players.map(p => ({ id: p.id, name: p.name, position: p.position, boostAvailable: p.boostAvailable, boostTimer: p.boostTimer })) });

    // check finish
    const winner = room.players.find(p => p.position >= FINISH_DISTANCE);
    if (winner) {
      room.finished = true;
      io.to(payload.room).emit('gameState', { players: room.players.map(p => ({ id: p.id, name: p.name, position: p.position })), finished: true });
      // send review / podium
      io.to(payload.room).emit('review', { players: room.players.map(p => ({ id: p.id, name: p.name, position: p.position })) });
      return;
    }

    // send next question to this player
    const nextQ = pickQuestion(room.level, room.currentIndex[player.id]);
    io.to(player.id).emit('playerQuestion', { playerId: player.id, question: nextQ });
  });

  socket.on('useBoost', (payload) => {
    // payload: { room, playerId }
    const room = rooms[payload.room];
    if (!room) return;
    const player = room.players.find(pl => pl.id === payload.playerId);
    if (!player) return;
    if (!player.boostAvailable) return;
    // consume the boost
    player.boostAvailable = false;
    player.boostTimer = 0;
    // pick the current question for that player and send info to remove one wrong choice
    const qIndex = room.currentIndex[player.id] || 0;
    const question = pickQuestion(room.level, qIndex);
    // choose a random wrong index
    const wrongIndexes = question.choices.map((c,i)=>i).filter(i=>i!==question.a);
    const removeIndex = wrongIndexes[Math.floor(Math.random()*wrongIndexes.length)];
    io.to(player.id).emit('boostActivated', { removeIndex });
    io.to(payload.room).emit('gameState', { players: room.players.map(p => ({ id: p.id, name: p.name, position: p.position, boostAvailable: p.boostAvailable })) });
  });

  socket.on('disconnect', () => {
    // remove player from any room
    for (const code of Object.keys(rooms)) {
      const room = rooms[code];
      const idx = room.players.findIndex(p => p.id === socket.id);
      if (idx !== -1) {
        const name = room.players[idx].name;
        room.players.splice(idx,1);
        io.to(code).emit('lobbyUpdate', { players: room.players.map(p => ({ id: p.id, name: p.name, position: p.position })) });
        console.log(`[room] ${name} (${socket.id}) déconnecté de ${code}`);
      }
    }
    console.log('[socket] déconnecté', socket.id);
  });

});

function pickQuestion(level, idx) {
  const bank = QUESTIONS[level] || QUESTIONS['easy'];
  return bank[idx % bank.length];
}

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Serveur en ligne sur le port ${PORT}`);
});
